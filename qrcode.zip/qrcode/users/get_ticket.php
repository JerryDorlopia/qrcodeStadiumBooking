<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qrcodegen";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize response array
$response = array();

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Validate and sanitize input
    $userId = isset($_GET['user_id']) ? mysqli_real_escape_string($conn, $_GET['user_id']) : null;

    // Check if required fields are set
    if ($userId !== null) {
        // Fetch data from the 'bookings' table
        $sql = "SELECT * FROM bookings WHERE user_id = $userId";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            // Initialize an array to store ticket details
            $tickets = array();

            while ($row = $result->fetch_assoc()) {
                // Add each ticket details to the array
                $tickets[] = $row;
            }

            $response['status'] = 'success';
            $response['tickets'] = $tickets;
        } else {
            $response['status'] = 'error';
            $response['message'] = 'No tickets found for you.';
        }
    } else {
        $response['status'] = 'error';
        $response['message'] = 'Invalid or missing input data';
    }
} else {
    $response['status'] = 'error';
    $response['message'] = 'Invalid request method';
}

// Close the database connection
$conn->close();

// Send JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
