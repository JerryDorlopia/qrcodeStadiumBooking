<?php
// Include your database connection file (e.g., dbcon.php)
include('../dbcon.php');
session_start();
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['registerSubmit'])) {
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT); // Hash the password

    try {
        // Assuming $conn is your database connection
        $query = $conn->prepare("INSERT INTO public_users (fname, lname, email, phone, password) VALUES (:fname, :lname, :email, :phone, :password)");
        $query->bindParam(':fname', $fname);
        $query->bindParam(':lname', $lname);
        $query->bindParam(':email', $email);
        $query->bindParam(':phone', $phone);
        $query->bindParam(':password', $password);

        if ($query->execute()) {
            echo "<script>alert('Registration successful!');</script>";
            header("Location: login.php");
            exit();       
         } else {
            echo "<script>alert('Registration failed. Please try again.');</script>";
        }
    } catch (PDOException $e) {
        echo 'Error: ' . $e->getMessage();
        // Handle the error as needed, e.g., log it or show an error message to the user.
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>QR Code Ticketing - Registration</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="robots" content="all,follow">

    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="/font-awesome/css/font-awesome.min.css">
    <!-- Fontastic Custom icon font-->
    <link rel="stylesheet" href="css/fontastic.css">
    <!-- Google fonts - Poppins -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,700">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/favicon.ico">

    <!-- Custom Styles for Registration Page -->
    <style>
        body {
            background: linear-gradient(45deg, #3498db, #2ecc71); /* Gradient background with blue and green */
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            margin: 0;
        }

        .form-card {
            background-color: rgba(255, 255, 255, 0.9); /* Semi-transparent white background */
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            width: 400px;
            transition: box-shadow 0.3s ease-in-out;
            padding: 20px;
            position: relative;
        }

        .form-card:hover {
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.2);
        }

        .form-card .content {
            padding: 40px;
            z-index: 1;
        }

        .form-card .content .form-group {
            margin-bottom: 20px;
            display: flex;
            flex-direction: column;
        }

        .form-card .content input {
            height: 40px;
            border-radius: 5px;
            border: 1px solid #ccc;
            padding: 10px;
            width: 100%;
            transition: border-color 0.3s ease-in-out;
        }

        .form-card .content input:hover {
            border-color: #007bff; /* Blue border on hover */
        }

        .form-card .content input:focus {
            outline: none;
            border-color: #007bff; /* Blue border when focused */
        }

        .form-card .content button {
            height: 40px;
            border-radius: 5px;
            border: none;
            color: #fff;
            background-color: #007bff;
            cursor: pointer;
            transition: background-color 0.3s ease-in-out;
        }

        .form-card .content button:hover {
            background-color: #0056b3; /* Darker blue on hover */
        }
    </style>

    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
        <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<!-- Form Panel    -->
<div class="login-page">
    <div class="form-card">
        <div class="content">
            <form class="form-validate" method="post" action="">
                <div class="form-group">
                    <input id="register-fname" type="text" name="fname" required class="input-material" placeholder="First Name">
                </div>
                <div class="form-group">
                    <input id="register-lname" type="text" name="lname" required class="input-material" placeholder="Last Name">
                </div>
                <div class="form-group">
                    <input id="register-email" type="email" name="email" required class="input-material" placeholder="Email Address">
                </div>
                <div class="form-group">
                    <input id="register-phone" type="text" name="phone" required class="input-material" placeholder="Phone Number">
                </div>
                <div class="form-group">
                    <input id="register-password" type="password" name="password" required class="input-material" placeholder="Password">
                </div>
                <div class="form-group">
                    <button type="submit" name="registerSubmit" class="btn btn-primary">Register</button>
                </div>
            </form>
        </div>
    </div>
</div>

<!-- JavaScript files-->
<script src="/jquery/jquery.min.js"></script>
<script src="/popper.js/umd/popper.min.js"> </script>
<script src="/bootstrap/js/bootstrap.min.js"></script>
<script src="/jquery.cookie/jquery.cookie.js"> </script>
<script src="/chart.js/Chart.min.js"></script>
<script src="/jquery-validation/jquery.validate.min.js"></script>
<!-- Main File-->
<script>
    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['registerSubmit'])) {
        echo "setTimeout(function() {
                window.location.href = 'matches.php';
            }, 3000);"; // Redirect to matches.php after 3 seconds
    }
    ?>
</script>
</body>
</html>
