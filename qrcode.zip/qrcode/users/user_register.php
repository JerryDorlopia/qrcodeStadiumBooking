<?php
include('dbcon.php'); // Include your database connection file

session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['registerSubmit'])) {
    $username = mysqli_real_escape_string($conn, $_POST['registerUsername']);
    $email = mysqli_real_escape_string($conn, $_POST['registerEmail']);
    $password = mysqli_real_escape_string($conn, $_POST['registerPassword']);
    $hashed_password = password_hash($password, PASSWORD_BCRYPT);

    // Check if the username or email is already registered
    $checkUserQuery = "SELECT * FROM useraccounts WHERE username='$username' OR email='$email'";
    $checkUserResult = $conn->query($checkUserQuery);

    if ($checkUserResult->num_rows > 0) {
        echo "<script>alert('Username or email already exists.');</script>";
    } else {
        // Insert user data into the database
        $insertUserQuery = "INSERT INTO useraccounts (username, email, password) VALUES ('$username', '$email', '$hashed_password')";

        if ($conn->query($insertUserQuery) === TRUE) {
            $_SESSION['message'] = "Registration successful! Please log in.";
            header("location: login.php");
            exit();
        } else {
            echo "Error: " . $insertUserQuery . "<br>" . $conn->error;
        }
    }
}

$conn->close();
?>

<!-- Remaining HTML Form for User Registration -->
<!-- Add this section to your existing HTML -->

<!-- Form Panel    -->
<div class="col-lg-6 bg-white">
    <div class="form d-flex align-items-center">
        <div class="content">
            <form class="form-validate" method="post" action="">
                <div class="form-group">
                    <input id="register-username" type="text" name="registerUsername" required data-msg="Please enter your username" class="input-material">
                    <label for="register-username" class="label-material">User Name</label>
                </div>
                <div class="form-group">
                    <input id="register-email" type="email" name="registerEmail" required data-msg="Please enter a valid email address" class="input-material">
                    <label for="register-email" class="label-material">Email Address</label>
                </div>
                <div class="form-group">
                    <input id="register-password" type="password" name="registerPassword" required data-msg="Please enter your password" class="input-material">
                    <label for="register-password" class="label-material">Password</label>
                </div>
                <div class="form-group terms-conditions">
                    <input id="register-agree" name="registerAgree" type="checkbox" required value="1" data-msg="Your agreement is required" class="checkbox-template">
                    <label for="register-agree">Agree the terms and policy</label>
                </div>
                <div class="form-group">
                    <button id="register" type="submit" name="registerSubmit" class="btn btn-primary">Register</button>
                </div>
            </form>
            <small>Already have an account? </small><a href="login.html" class="signup">Login</a>
        </div>
    </div>
</div>
