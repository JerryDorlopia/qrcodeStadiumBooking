<?php
// Include your database connection file (e.g., dbcon.php)
include('../dbcon.php');
session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['loginSubmit'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];
    // Retrieve hidden field values
    $selectedEventId = $_POST['selectedEventId'];
    $selectedTeam1 = $_POST['selectedTeam1'];
    $selectedTeam2 = $_POST['selectedTeam2'];
    $eventTitle = $_POST['eventTitle'];
    $matchDate = $_POST['matchDate'];
    $eventStartTime = $_POST['eventStartTime'];
    $eventEndTime = $_POST['eventEndTime'];

    try {
        // Assuming $conn is your database connection
        $query = $conn->prepare("SELECT * FROM public_users WHERE email=:email");
        $query->bindParam(':email', $email);
        $query->execute();

        $user = $query->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['user_id'];
            // Add other session variables as needed
            $_SESSION['selectedEventId'] = $selectedEventId;
            $_SESSION['selectedTeam1'] = $selectedTeam1;
            $_SESSION['selectedTeam2'] = $selectedTeam2;
            $_SESSION['eventTitle'] = $eventTitle;
            $_SESSION['matchDate'] = $matchDate;
            $_SESSION['eventStartTime'] = $eventStartTime;
            $_SESSION['eventEndTime'] = $eventEndTime;

            // Redirect to select_seat.php
            header("Location: select_seat.php");
            exit();
        } else {
            echo "<script>alert('User not found or incorrect password...');</script>";
        }
    } catch (PDOException $e) {
        echo 'Error: ' . $e->getMessage();
        // Handle the error as needed, e.g., log it or show an error message to the user.
    }
}
?>




<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>MyTikay - Event Ticket Booking</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="robots" content="all,follow">

    <!-- Bootstrap CSS-->
    <link rel="stylesheet" href="/bootstrap/css/bootstrap.min.css">
    <!-- Font Awesome CSS-->
    <link rel="stylesheet" href="/font-awesome/css/font-awesome.min.css">
    <!-- Fontastic Custom icon font-->
    <link rel="stylesheet" href="css/fontastic.css">
    <!-- Google fonts - Poppins -->
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Poppins:300,400,700">
    <!-- theme stylesheet-->
    <link rel="stylesheet" href="css/style.default.css" id="theme-stylesheet">
    <!-- Custom stylesheet - for your changes-->
    <link rel="stylesheet" href="css/custom.css">
    <!-- Favicon-->
    <link rel="shortcut icon" href="img/favicon.ico">

    <!-- Custom Styles for Login Page -->
    <style>
        body {
            background: linear-gradient(45deg, #3498db, #2ecc71, #e74c3c); /* Multiple background colors */
            overflow: hidden; /* Hide overflow to prevent scrolling during animation */
        }

        .login-page {
            height: 100vh;
            display: flex;
            align-items: center;
            justify-content: center;
            position: relative;
        }

        .form-card {
            background-color: rgba(255, 255, 255, 0.9); /* Semi-transparent white background */
            border-radius: 10px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.1);
            overflow: hidden;
            width: 400px;
            transition: box-shadow 0.3s ease-in-out;
            padding: 20px;
            position: relative;
        }

        .form-card::before {
            content: "";
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: url('img/ticket-background.jpg') repeat; /* Add the path to your ticket background image */
            opacity: 0.3;
            z-index: -1;
            animation: backgroundAnimation 20s linear infinite; /* Background animation */
        }

        @keyframes backgroundAnimation {
            from {
                background-position: 0 0;
            }
            to {
                background-position: 100% 100%;
            }
        }

        .form-card .content {
            padding: 40px;
            z-index: 1;
        }

        .form-card .content h2 {
            color: #333; /* Dark color for headings */
            margin-bottom: 20px;
            display: flex;
            align-items: center;
            justify-content: center;
        }

        .form-card .content h2 img {
            margin-right: 10px;
            max-width: 120px; /* Increased logo size */
            max-height: 120px; /* Increased logo size */
            border-radius: 5%; /* Rounded corners for the logo */
        }

        .form-card .content label {
            font-weight: 500;
            color: #333; /* Dark color for labels */
        }

        .form-card .content .form-group {
            margin-bottom: 20px;
        }

        .form-card .content input {
            height: 40px;
            border-radius: 5px;
            border: none;
            padding: 10px;
            width: 100%;
            background-color: rgba(255, 255, 255, 1); /* White background */
            color: #333; /* Dark text color */
        }

        .form-card .content button {
            height: 40px;
            border-radius: 5px;
            border: none;
            color: #fff;
            background-color: #e74c3c; /* Red color for button */
            cursor: pointer;
            transition: background-color 0.3s ease-in-out;
        }

        .form-card .content button:hover {
            background-color: #c0392b; /* Darker red on hover */
        }

        .form-card .content .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-card .content .form-group label {
            margin-bottom: 5px;
        }

        .form-card .content .form-group input {
            margin-bottom: 10px;
        }

        .login-page .form-card {
            background-color: rgba(255, 255, 255, 0.9); /* Semi-transparent white background */
            color: #333; /* Dark text color */
        }

        .login-page .form-card .content {
            padding: 40px;
        }

        .login-page .form-card .content label {
            color: #333; /* Dark label text color */
        }

        .login-page .form-card .content input {
            background-color: rgba(255, 255, 255, 1); /* White background */
            border: 1px solid #ccc;
            color: #333; /* Dark text color */
        }

        .login-page .form-card .content button {
            background-color: #27ae60; /* Green color for button */
        }

        .login-page .form-card .content button:hover {
            background-color: #218c53; /* Darker green on hover */
        }

        @media (max-width: 480px) {
            .form-card {
                width: 90%;
            }

            .form-card .content h2 img {
                max-width: 80px;
                max-height: 80px;
            }
        }
    </style>

    <!-- Tweaks for older IEs--><!--[if lt IE 9]>
    <script src="https://oss.maxcdn.com/html5shiv/3.7.3/html5shiv.min.js"></script>
    <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
    <![endif]-->
</head>
<body>
<!-- Form Panel    -->
<div class="login-page">
    <div class="form-card">
        <div class="content">
            <div class="company-logo">
                <h2><img src="uploads/ticket-logo.png" alt="MyTikay Logo"></h2>
            </div>
            <form class="form-validate" method="post" action="login.php">
                <!-- Hidden fields to store selected event_id and team information -->
                <input type="hidden" id="selectedEventId" name="selectedEventId" value="<?php echo isset($_POST['selectedEventId']) ? htmlspecialchars($_POST['selectedEventId']) : ''; ?>">
                <input type="hidden" id="selectedTeam1" name="selectedTeam1" value="<?php echo isset($_POST['selectedTeam1']) ? htmlspecialchars($_POST['selectedTeam1']) : ''; ?>">
                <input type="hidden" id="selectedTeam2" name="selectedTeam2" value="<?php echo isset($_POST['selectedTeam2']) ? htmlspecialchars($_POST['selectedTeam2']) : ''; ?>">
                <!-- Additional hidden fields for event information -->
                <input type="hidden" id="eventTitle" name="eventTitle" value="<?php echo isset($_POST['eventTitle']) ? htmlspecialchars($_POST['eventTitle']) : ''; ?>">
                <input type="hidden" id="matchDate" name="matchDate" value="<?php echo isset($_POST['matchDate']) ? htmlspecialchars($_POST['matchDate']) : ''; ?>">
                <input type="hidden" id="eventStartTime" name="eventStartTime" value="<?php echo isset($_POST['eventStartTime']) ? htmlspecialchars($_POST['eventStartTime']) : ''; ?>">
                <input type="hidden" id="eventEndTime" name="eventEndTime" value="<?php echo isset($_POST['eventEndTime']) ? htmlspecialchars($_POST['eventEndTime']) : ''; ?>">

                <div class="form-group">
                    <input id="login-email" type="email" name="email" required class="input-material">
                    <label for="login-email" class="label-material">Email Address</label>
                </div>
                <div class="form-group">
                    <input id="login-password" type="password" name="password" required class="input-material">
                    <label for="login-password" class="label-material">Password</label>
                </div>
                <div class="form-group">
                    <button type="submit" name="loginSubmit" class="btn btn-primary">Login</button>
                </div>
                <!-- Add the Register button -->
<div class="form-group">
    <a href="register.php" class="btn btn-secondary">Register</a>
</div>
            </form>
        </div>
    </div>
</div>


<!-- JavaScript files-->
<script src="/jquery/jquery.min.js"></script>
<script src="/popper.js/umd/popper.min.js"> </script>
<script src="/bootstrap/js/bootstrap.min.js"></script>
<script src="/jquery.cookie/jquery.cookie.js"> </script>
<script src="/chart.js/Chart.min.js"></script>
<script src="/jquery-validation/jquery.validate.min.js"></script>
<!-- Main File-->
<script src="js/front.js"></script>
</body>
</html>