<?php
session_start();

// Check if the user is not logged in, redirect to login page
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Retrieve session variables
$selectedEventId = $_SESSION['selectedEventId'];
$selectedTeam1 = $_SESSION['selectedTeam1'];
$selectedTeam2 = $_SESSION['selectedTeam2'];
$eventTitle = $_SESSION['eventTitle'];
$matchDate = $_SESSION['matchDate'];
$eventStartTime = $_SESSION['eventStartTime'];
$eventEndTime = $_SESSION['eventEndTime'];

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qrcodegen";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch the user's name and user_id based on the session
$user_id = $_SESSION['user_id'];
$query = $conn->prepare("SELECT user_id, fname, lname FROM public_users WHERE user_id = ?");
$query->bind_param('i', $user_id);
$query->execute();
$userData = $query->get_result()->fetch_assoc();

// Check if the query was successful
if (!$userData) {
    // Redirect to login if the user data is not found
    header("Location: login.php");
    exit();
}

// Fetch booked seats
$bookedSeats = array();
$sql = "SELECT seat_row, seat_col FROM bookings";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $bookedSeats[] = array('row' => $row['seat_row'], 'col' => $row['seat_col']);
    }
}

// Count of total seats
$totalSeats = 21400;

// Count of booked seats
$bookedSeatsCount = count($bookedSeats);

// Count of available seats
$availableSeatsCount = $totalSeats - $bookedSeatsCount;

// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Seat Booking System</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>


</head>

<body>
<div class="page">
    <div class="sidebar">
        <div class="seat-colors">            
       <!-- Add this where you want the logout link/icon -->

            <h3 style="text-decoration: underline">Seat Colors</h3>
            <div>

                <p style="text-align: left;">Total Seats = <?php echo $totalSeats; ?></p>
                <p>Booked Seats = <?php echo $bookedSeatsCount; ?></p>
                <p>Available Seats = <?php echo $availableSeatsCount; ?></p>
                <p style="text-align: left;">MAX Seletable/user = <strong>2</strong></p>

            </div>
            <div class="seat-box">
                <div class="color-box" style="background-color: #dee2e6;"></div>
                <p>No Seat (empty area)</p>
            </div>
            <div class="seat-box">
                <div class="color-box" style="background-color: #ff0000;"></div>
                <p>Booked Seat</p>
            </div>
            <div class="seat-box">
                <div class="color-box" style="background-color: #ffffff; border: 1px solid #4caf50; color: #4caf50;">✓</div>
                <p>Selectable Seat</p>
            </div>
            <div class="seat-box">
                <div class="color-box" style="background-color: green;"></div>
                <p>Around the Field (600 rwf)</p>
            </div>
            <!--<div class="seat-box">
                <div class="color-box" style="background-color: gold;"></div>
                <p>Around the Field ($6) ($6)</p>
            </div>-->
            <div class="seat-box">
                <div class="color-box" style="background-color: #fff;"></div>
                <p>Ordinary Class (200 rwf)</p>
            </div>
        </div>
            <!-- Add the print ticket button with a print icon -->
            <div class="button-container">
            
                <button class="btn btn-success" id="book-seats-btn">Book Seats</button>
                                <!-- Inside your HTML -->
                <button class="btn btn-primary" id="print-ticket-btn">
                    <i class="fas fa-print"></i> Print Ticket
                </button>

            </div>

        </div>

<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>
<!-- Your existing HTML code -->
<!-- Add the right sidebar with gate buttons -->
<div class="gate-sidebar">
    <h3 style="text-decoration: underline;color:#0c96f1;"> Select a gate</h3>
    <button style="background-color:gold;" class="gate-button vip-front-class" onclick="selectGate('VIP')">VIP Gate</button>

    <?php for ($gate = 1; $gate <= 15; $gate++) { ?>
        <button class="gate-button" onclick="selectGate(<?php echo $gate; ?>)">Gate <?php echo $gate; ?></button>
    <?php } ?>
</div>

<div class="content">
    <?php
    // Check if there is session data
    if (empty($userData) || empty($selectedEventId) || empty($selectedTeam1) || empty($selectedTeam2)) {
        echo '<div class="alert alert-warning" role="alert" style="margin-bottom: 15px;">
                Please go to <a href="matches.php">matches</a> and select a match before booking.
              </div>';
        echo '<a style="display: inline-block; padding: 10px 20px; font-size: 16px; text-align: center; text-decoration: none; background-color: #007bff; color: #fff; border-radius: 5px; cursor: pointer;" href="matches.php">Go to Matches</a>';
    } else {
        // Display selected event and team information
        echo '<div class="sticky-top flex">
                <div class="gate-info">
                    <p class="gate-selected">Selected Gate: 1</p>
                </div>
                <p>You Selected: ' . $selectedTeam1 . ' Vs ' . $selectedTeam2 . '</p>
                <div class="user-info-container">
                    <p class="user-info">
                        Welcome, ' . $userData['fname'] . ' ' . $userData['lname'] . '!
                        <span class="logout-link">
                            <i class="fas fa-sign-out-alt"></i>
                            <div class="logout-dialog">
                                <p>Are you sure you want to logout?</p>
                                <button onclick="confirmLogout()">Yes</button>
                                <button onclick="cancelLogout()">No</button>
                            </div>
                        </span>
                    </p>
                </div>
              </div>
              <br><br><br>';
    }
    ?>




   <!-- Add a container for each gate's table -->
   <?php for ($gate = 1; $gate <= 15; $gate++) { ?>
    <div class="table-container gate-table" id="table-gate-<?php echo $gate; ?>" style="display: <?php echo ($gate === 1) ? 'block' : 'none'; ?>;">
        <table>
            <thead>
                <tr>
                    <th></th>
                    <?php for ($i = 0; $i <= 14; $i++) { ?>
                        <th><?php echo $i; ?></th>
                    <?php } ?>
                </tr>
            </thead>
            <tbody>
                <?php
                // Fetch booked seats for the selected gate from the database
                $selectedGateBookedSeats = fetchBookedSeatsForGate($gate);

                for ($i = 0; $i <= 23; $i++) {
                    echo "<tr>";
                    // Display the left number line for rows
                    echo "<td>$i</td>";

                    for ($j = 0; $j <= 14; $j++) {
                        $isBooked = in_array(array('row' => $i, 'col' => $j), $selectedGateBookedSeats);

                        if ($i == 3 || $i == 7 || $i == 11 || $i == 15 || $i == 19 || $i == 23 || $j == 7) {
                            // No seat in rows 7, 11, 15, and column 14
                            echo "<td class='no-seat'></td>";
                        } else {
                            // Gold Front Class
                            $goldClass = ($i >= 0 && $i <= 2 && $j >= 0 && $j <= 14) ? 'gold-front-class' : '';
                            // Middle Class
                            $middleClass = ($i >= 20 && $i <= 22 && $j >= 0 && $j <= 14) ? 'middle-class' : '';
                            // Cream Class
                            $creamClass = ($goldClass == '' && $middleClass == '') ? 'cream-class' : '';
                            $seatClass = "seat $goldClass $middleClass $creamClass";
                            $seatContent = '';

                            if ($isBooked) {
                                // Seat is booked, hide checkbox and change cell color to red
                                $seatClass .= ' booked-seat';
                                $seatContent .= "<input type='checkbox' class='seat-checkbox' style='display: none;'>";
                            } else {
                                // Seat is not booked, enable checkbox
                                $seatContent .= "<input type='checkbox' class='seat-checkbox'>";
                            }

                            // Display seat number in the format "R1,C2"
                            $seatNumber = "R$i,C$j";
                            echo "<td class='$seatClass' data-id='$i-$j'><div class='seat-number'>$seatNumber</div>$seatContent</td>";
                        }
                    }
                    echo "</tr>";
                }
                ?>

                <tr>
                    <td></td>
                    <?php for ($i = 0; $i <= 14; $i++) { ?>
                        <td class="seat-number"><?php echo $i; ?></td>
                    <?php } ?>
                </tr>
            </tbody>
        </table>
    </div>
<?php } ?>
<?php
// Function to fetch booked seats for the selected gate from the database
function fetchBookedSeatsForGate($gate) {
    $host = "localhost";
    $username = "root";
    $password = "";
    $database = "qrcodegen";

    // Create a database connection
    $conn = new mysqli($host, $username, $password, $database);

    // Check the connection
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // Use prepared statements to prevent SQL injection
    $query = "SELECT seat_row, seat_col FROM bookings WHERE gate_id = ?";

    // Prepare the statement
    $stmt = $conn->prepare($query);

    // Check if the preparation was successful
    if (!$stmt) {
        die("Prepare failed: (" . $conn->errno . ") " . $conn->error);
    }

    // Bind the parameter
    $stmt->bind_param("i", $gate);

    // Execute the query
    $result = $stmt->execute();

    // Check if the execution was successful
    if (!$result) {
        die("Execute failed: (" . $stmt->errno . ") " . $stmt->error);
    }

    // Bind the result variables
    $stmt->bind_result($row, $col);

    // Fetch the results into an array
    $bookedSeats = [];
    while ($stmt->fetch()) {
        $bookedSeats[] = ['row' => $row, 'col' => $col];
    }

    // Close the statement and connection
    $stmt->close();
    $conn->close();

    return $bookedSeats;
}
?>


<!-- Your existing JavaScript code -->
<script>
    document.addEventListener("DOMContentLoaded", function () {
    // Get all gate buttons
    var gateButtons = document.querySelectorAll(".gate-button");

    // Add click event listener to each gate button
    gateButtons.forEach(function (button) {
        button.addEventListener("click", function () {
            // Remove the "selected-gate-button" class from all buttons
            gateButtons.forEach(function (btn) {
                btn.classList.remove("selected-gate-button");
            });

            // Add the "selected-gate-button" class to the clicked button
            button.classList.add("selected-gate-button");

            // Update the selected gate text
            var selectedGateText = document.querySelector(".gate-selected");
            selectedGateText.textContent = "Selected Gate: " + button.textContent;

            // Show/hide the corresponding table based on the clicked button
            var gateNumber = button.getAttribute("data-gate-number");
            showTable(gateNumber);
        });
    });

    // Function to show/hide tables based on the selected gate button
    function showTable(selectedGate) {
        // Hide all tables
        var tables = document.querySelectorAll(".gate-table");
        tables.forEach(function (table) {
            table.style.display = "none";
        });

        // Show the selected table
        var selectedTable = document.getElementById("table-gate-" + selectedGate);
        if (selectedTable) {
            selectedTable.style.display = "block";
        }
    }
});

document.addEventListener('DOMContentLoaded', function () {
    const seatPrices = {
        frontClass: 800,
        middleClass: 200,
        ordinaryClass: 600,
    };

    let selectedGateId = 1; // Default gate

    function toggleSeatSelection(cell) {
        cell.classList.toggle('selected-seat');
    }

    function getRowAndCol(cell) {
        const seatId = cell.getAttribute('data-id');
        const [row, col] = seatId.split('-').map(Number);
        return { row, col };
    }

    function calculateTotalAmount(seats) {
        return seats.reduce((total, seat) => {
            if (seat.row >= 0 && seat.row <= 2 && seat.col >= 0 && seat.col <= 14) {
                return total + seatPrices.frontClass;
            } else if (seat.row >= 12 && seat.row <= 14 && seat.col >= 0 && seat.col <= 14) {
                return total + seatPrices.middleClass;
            } else {
                return total + seatPrices.ordinaryClass;
            }
        }, 0);
    }
    const maxSelectedSeats = 4;

// Assume the user tries to select a seat
function handleSeatSelection() {
    const selectedSeatsInfo = document.querySelectorAll('.table-container .seat-checkbox:checked');

    if (selectedSeatsInfo.length > maxSelectedSeats) {
        alert(`You can only select up to ${maxSelectedSeats} seats.`);
        const lastSelectedCheckbox = document.querySelector('.table-container .seat-checkbox:checked');
        lastSelectedCheckbox.checked = false;
    }
}

// Attach the function to the change event of the checkboxes
const seatCheckboxes = document.querySelectorAll('.table-container .seat-checkbox');
seatCheckboxes.forEach((checkbox) => {
    checkbox.addEventListener('change', handleSeatSelection);
});

    function updateSelectedSeats() {
        const selectedSeatsInfo = [];
        const allCheckboxes = document.querySelectorAll('.table-container .seat-checkbox');

        allCheckboxes.forEach(function (checkbox) {
            if (checkbox.checked) {
                const cell = checkbox.closest('.seat');
                const { row, col } = getRowAndCol(cell);
                selectedSeatsInfo.push({ row, col });
            }
        });

        

        const displayList = document.getElementById('selected-seats-display');
        displayList.innerHTML = '';

        const totalAmountField = document.getElementById('total_amount');
        const totalAmount = calculateTotalAmount(selectedSeatsInfo);

        if (selectedSeatsInfo.length > 0) {
            selectedSeatsInfo.forEach(function (seat) {
                const listItem = document.createElement('li');
                listItem.textContent = `Row: ${seat.row}, Column: ${seat.col}`;
                displayList.appendChild(listItem);
            });
        } else {
            const listItem = document.createElement('li');
            listItem.textContent = 'No seats selected';
            displayList.appendChild(listItem);
        }

        document.getElementById('selected-seats-ids').value = JSON.stringify(selectedSeatsInfo);
        totalAmountField.value = `${totalAmount}`;
    }

    document.querySelector('.table-container').addEventListener('change', function (event) {
        const target = event.target;
        if (target.classList.contains('seat-checkbox')) {
            updateSelectedSeats();
        }
    });

    function openPopup() {
        const selectedSeats = document.querySelectorAll('.table-container .seat-checkbox:checked');
        if (selectedSeats.length === 0) {
            alert('Please select at least one seat before booking.');
            return;
        }

        updateSelectedSeats();

        document.getElementById('popup-overlay').style.display = 'block';
        document.getElementById('booking-popup').style.display = 'block';
    }

    function closePopup() {
        const allCheckboxes = document.querySelectorAll('.table-container .seat-checkbox');
        allCheckboxes.forEach(function (checkbox) {
            checkbox.checked = false;
        });

        updateSelectedSeats();

        document.getElementById('popup-overlay').style.display = 'none';
        document.getElementById('booking-popup').style.display = 'none';
    }

    function selectGate(gateNumber) {
        selectedGateId = gateNumber;

        $('.gate-selected').text('Selected Gate: ' + gateNumber);
        $('#selected-gate').val(gateNumber);

        $('.gate-table').hide();
        $('#table-gate-' + gateNumber).show();

        $.ajax({
            type: 'GET',
            url: 'get_ticket.php',
            data: { gate: gateNumber },
            dataType: 'json',
            success: function(response) {
                if (response.status === 'success') {
                    updateTable(response.seats);
                } else {
                    // Handle no seats found
                }
            },
            error: function() {
                // Handle AJAX error
            }
        });
    }

    function updateTable(seats) {
        $('.seat').removeClass('selected-seat');

        for (let i = 0; i < seats.length; i++) {
            const row = seats[i].row;
            const col = seats[i].col;
            const seatId = '#seat-' + row + '-' + col;
            $(seatId).addClass('selected-seat');
        }
    }

    $('.gate-table').hide();
    $('#table-gate-1').show();

    $('.gate-button').click(function() {
        const gateNumber = $(this).text().replace('Gate ', '');
        selectGate(gateNumber);
    });

    document.getElementById('book-seats-btn').addEventListener('click', openPopup);
    document.getElementById('close-popup-btn').addEventListener('click', closePopup);
});

</script>

<style>
        /* Add your CSS styles here */
        .popup {
            display: none;
            /* Add other styling properties as needed */
        }
    </style>


<?php
// Check if the session variable is not set
if (!isset($_SESSION['showBookingPopup'])) {
    // Set the session variable
    $_SESSION['showBookingPopup'] = true;
?>
    <div class="popup-overlay" id="popup-overlay"></div>

    <!-- Step 1: Booking Form -->
    <div class="popup" id="booking-popup">
        <button type="button" id="close-popup-btn" onclick="closePopup()">X</button>
        <br>
        <h2>Book Seats - Step 1</h2>
        <form id="booking-form" onsubmit="submitStep1(event)">
            <!-- Display selected seats -->
            <p>Selected Seats:</p>
            <ul id="selected-seats-display" class="selected-seats-list"></ul>
            <input type="hidden" name="selected-seats-ids" id="selected-seats-ids" value="">
            <input type="hidden" name="user_id" value="<?php echo $userData['user_id']; ?>">
            <input type="hidden" name="selected-gate" id="selected-gate" value="">

            <!-- Add more fields for booker information -->
            <div class="form-group">
                <input type="text" name="booker_name" id="booker_name" placeholder="Enter your name.." required>
            </div>
            <div class="form-group">
                <input type="email" name="booker_email" id="booker_email" placeholder="Enter your email.." required>
            </div>
            <div class="form-group">
                <input type="tel" name="booker_phone" id="booker_phone" placeholder="Enter your phone#" required>
            </div>
            <!-- Display selected event information -->
            <input type="hidden" name="selectedEventId" value="<?php echo $selectedEventId; ?>" readonly>
            <input type="hidden" name="selectedTeam1" value="<?php echo $selectedTeam1; ?>" readonly>
            <input type="hidden" name="selectedTeam2" value="<?php echo $selectedTeam2; ?>" readonly>
            <input type="hidden" name="eventTitle" value="<?php echo $eventTitle; ?>" readonly>
            <input type="hidden" name="matchDate" value="<?php echo $matchDate; ?>" readonly>
            <input type="hidden" name="eventStartTime" value="<?php echo $eventStartTime; ?>" readonly>
            <input type="hidden" name="eventEndTime" value="<?php echo $eventEndTime; ?>" readonly>

            <button type="button" onclick="nextStep()">Next</button>
        </form>
    </div>
<?php
}

// Unset the session variable to prevent the popup from showing on subsequent page loads
unset($_SESSION['showBookingPopup']);
?>
<!-- Step 2: Momo Money Payment Form -->
<div class="popup step-2-form" id="momo-payment-popup">
    <button type="button" id="close-momo-payment-btn" onclick="closePopup()">X</button>
    <h2>Momo Payment - Step 2</h2>
    <form id="momo-payment-form" action="process_payment.php" method="POST">
        <!-- Step 2 content -->
        <div class="form-group">
            <input type="tel" name="momo_number" id="momo_number" placeholder="Enter your momo number.." required>
        </div>
<br>
        <!-- Add total field -->
        <div class="form-group">
            <input type="text" name="total_amount" id="total_amount" >
            <input type="hidden" name="hidden_total_amount" id="hidden_total_amount">
        </div>
        <button type="submit">Submit Momo Payment</button>
    </form>
</div>

<style>
    /* Add styles for the Step 2 form background */
    .step-2-form {
        background: url('uploads/momo.png') rgba(255, 255, 255, 0.5); /* Replace with the actual path to your image */
        background-size: cover;
        background-position: center;
        background-repeat: no-repeat;
        padding: 40px; /* Adjust padding to ensure content is readable */
        border: 1px solid #ccc;
        box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        
    }
</style>



<script>
    // JavaScript code
    let currentStep = 1;
    function nextStep() {
    if (currentStep === 1) {
        // Get total amount from step 1 form
        const totalAmount = document.getElementById('total_amount').value;

        // Set total amount value in step 2 form
        document.getElementById('hidden_total_amount').value = totalAmount;

        console.log(totalAmount);  // Add this line for debugging

        document.getElementById('booking-popup').style.display = 'none';
        document.getElementById('momo-payment-popup').style.display = 'block';
        currentStep = 2;
    }
}

    function closePopup() {
        document.getElementById('popup-overlay').style.display = 'none';
        document.getElementById('booking-popup').style.display = 'none';
        document.getElementById('momo-payment-popup').style.display = 'none';
        currentStep = 1;
    }

    function submitStep1(event) {
        // Handle submission of step 1
        event.preventDefault();
        // Additional logic for step 1 submission
        nextStep(); // Move to step 2
    }
</script>


<!-- Inside your HTML, after the booking-popup div -->
<div class="popup" id="download-ticket-popup">
    <button type="button" id="close-ticket-popup-btn" onclick="closeTicketPopup()">X</button>
    <h2>Download Ticket</h2>
    <form id="download-ticket-form" onsubmit="downloadTicket(event)">
        <!-- Display ticket details here -->
        <div id="ticket-details"></div>

        <button type="submit">Print Ticket</button>
    </form>
</div>
<script>
    function closeTicketPopup() {
    var popupOverlay = document.getElementById('popup-overlay');
    var downloadTicketPopup = document.getElementById('download-ticket-popup');

    if (popupOverlay && downloadTicketPopup) {
        popupOverlay.style.display = 'none';
        downloadTicketPopup.style.display = 'none';
    } else {
        console.error('Popup elements not found.');
    }
}

</script>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        // Function to toggle seat selection
        function toggleSeatSelection(cell) {
            cell.classList.toggle('selected-seat');
        }

        // Function to get row and column numbers from data-id
        function getRowAndCol(cell) {
            var seatId = cell.getAttribute('data-id');
            var [row, col] = seatId.split('-').map(Number);
            return { row, col };
        }

        // Define seat prices
        const seatPrices = {
            frontClass: 8,
            middleClass: 6,
            ordinaryClass: 4,
        };

        // Function to update the selected seats information and total amount
        function updateSelectedSeats() {
            var selectedSeatsInfo = [];

            // Select all checkboxes within the table
            var allCheckboxes = document.querySelectorAll('.table-container .seat-checkbox');

            allCheckboxes.forEach(function (checkbox) {
                if (checkbox.checked) {
                    var cell = checkbox.closest('.seat');
                    var { row, col } = getRowAndCol(cell);
                    selectedSeatsInfo.push({ row, col });
                }
            });

            
            // Update the display
            var displayList = document.getElementById('selected-seats-display');
            displayList.innerHTML = '';

            var totalAmountField = document.getElementById('total_amount');
            var totalAmount = calculateTotalAmount(selectedSeatsInfo);

            if (selectedSeatsInfo.length > 0) {
                selectedSeatsInfo.forEach(function (seat) {
                    var listItem = document.createElement('li');
                    listItem.textContent = `Row: ${seat.row}, Column: ${seat.col}`;
                    displayList.appendChild(listItem);
                });
            } else {
                var listItem = document.createElement('li');
                listItem.textContent = 'No seats selected';
                displayList.appendChild(listItem);
            }

            // Update the hidden field value
            document.getElementById('selected-seats-ids').value = JSON.stringify(selectedSeatsInfo);

            // Update the total amount field
            totalAmountField.value = `$${totalAmount}`;
        }

        // Function to calculate the total amount based on seat prices
        function calculateTotalAmount(seats) {
            var totalAmount = 0;

            seats.forEach(function (seat) {
                // Check the class of the seat and add the corresponding price
                if (seat.row >= 0 && seat.row <= 2 && seat.col >= 0 && seat.col <= 14) {
                    totalAmount += seatPrices.frontClass;
                } else if (seat.row >= 12 && seat.row <= 14 && seat.col >= 0 && seat.col <= 14) {
                    totalAmount += seatPrices.middleClass;
                } else {
                    totalAmount += seatPrices.ordinaryClass;
                }
            });

            return totalAmount;
        }

        // Event listener for seat clicks
        document.querySelector('.table-container').addEventListener('change', function (event) {
            var target = event.target;
            if (target.classList.contains('seat-checkbox')) {
                // Update the selected seats information
                updateSelectedSeats();
            }
        });

        // Function to open the popup
        function openPopup() {
            // Check if seats are selected
            var selectedSeats = document.querySelectorAll('.table-container .seat-checkbox:checked');
            if (selectedSeats.length === 0) {
                alert('Please select at least one seat before booking.');
                return;
            }

            document.getElementById('popup-overlay').style.display = 'block';
            document.getElementById('booking-popup').style.display = 'block';
        }

        // Function to close the popup and reset selected seats
        function closePopup() {
            // Deselect all checkboxes
            var allCheckboxes = document.querySelectorAll('.table-container .seat-checkbox');
            allCheckboxes.forEach(function (checkbox) {
                checkbox.checked = false;
            });

            // Update the selected seats information
            updateSelectedSeats();

            // Close the popup
            document.getElementById('popup-overlay').style.display = 'none';
            document.getElementById('booking-popup').style.display = 'none';
        }

        function submitForm(event) {
            event.preventDefault();

            // Get selected seats information
            var selectedSeatsInfo = JSON.parse(document.getElementById('selected-seats-ids').value);

            // Create a FormData object to serialize the form data
            var formData = new FormData(document.getElementById('booking-form'));
            formData.append('selected-seats-ids', JSON.stringify(selectedSeatsInfo));

            // Perform AJAX request to submit the form data
            fetch('submit_bookings.php', {
                    method: 'POST',
                    body: formData,
                })
                .then(response => response.json())
                .then(data => {
                    // Log the response data to the console
                    console.log(data);

                    // Check if the submission was successful
                    if (data.status === 'success') {
                        // Optionally, display a success message to the user
                        alert(data.message);
                    } else {
                        // Display an error message to the user
                        alert('Error: ' + data.message);
                    }
                })
                .catch(error => {
                    console.error('Error:', error);
                })
                .finally(() => {
                    // After successful or unsuccessful submission, close the popup
                    closePopup();
                });
        }
        // Attach click event to the "Book Seats" button
        document.getElementById('book-seats-btn').addEventListener('click', openPopup);

        // Attach click event to the "X" button
        document.getElementById('close-popup-btn').addEventListener('click', closePopup);

        // Attach submit event to the form
        document.getElementById('booking-form').addEventListener('submit', submitForm);

// Function to open the download ticket popup
function openTicketPopup() {
    // Display the download ticket popup
    document.getElementById('popup-overlay').style.display = 'block';
    document.getElementById('download-ticket-popup').style.display = 'block';

    // Fetch ticket details using AJAX
    var userId = <?php echo $userData['user_id']; ?>;
    fetch('get_ticket.php?user_id=' + userId)
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success' && data.tickets) {
                // Display ticket details in the modal
                populateTicketDetails(data.tickets);
            } else {
                // Display an error message
                alert('Error: ' + data.message);
            }
        })
        .catch(error => {
            console.error('Error:', error);
        });
        
}

 // Function to populate ticket details in the ticket popup
 function populateTicketDetails(tickets) {
        // Create a container for all tickets
        var ticketsContainer = document.getElementById('ticket-details');
        ticketsContainer.innerHTML = '';

        // Iterate over each ticket and create formatted HTML
        tickets.forEach(ticket => {
            var ticketHTML = `
                <div class="ticket">
                    <div class="ticket-left">
                        <p class="ticket-heading">Soccer Match Ticket</p>
                        <p class="ticket-info">Gate#: ${ticket.gate_id}</p>
                        <p class="ticket-info">Seat: R${ticket.seat_row}, C${ticket.seat_col}</p>
                        <p class="ticket-info">Booker: ${ticket.booker_name}</p>
                        <p class="ticket-info">Class: ${ticket.seat_class}</p>
                        <p class="ticket-info">Match ID: ${ticket.match_id}</p>
                        <p class="ticket-price">Price: $${ticket.total}</p>
                        
                    </div>
                    <div class="ticket-right">
                        <div class="qr-code"></div> <!-- Add a div for QR code -->
                    </div>
                </div>
            `;

            // Append the ticket HTML to the container
            ticketsContainer.innerHTML += ticketHTML;
        });
    }

// Function to close the download ticket popup
function closeTicketPopup() {
    // Close the download ticket popup
    document.getElementById('popup-overlay').style.display = 'none';
    document.getElementById('download-ticket-popup').style.display = 'none';
    
}

// Function to handle the download ticket form submission
function downloadTicket(event) {
    event.preventDefault();

    // Perform any additional actions needed for downloading the ticket
    // (e.g., trigger a download, open a new window, etc.)

    // Close the download ticket popup
    closeTicketPopup();
}

// Attach click event to the "Print Ticket" button
document.getElementById('print-ticket-btn').addEventListener('click', openTicketPopup);





    });
</script>
<!-- Your HTML code -->
<script>
    // JavaScript to toggle the visibility of the confirmation dialog
    function confirmLogout() {
        window.location.href = "logout.php"; // Redirect to logout page if confirmed
    }

    function cancelLogout() {
        document.querySelector('.logout-dialog').style.display = 'none'; // Hide the confirmation dialog
    }

    // Show confirmation dialog on click
    document.querySelector('.logout-link').addEventListener('click', function() {
        document.querySelector('.logout-dialog').style.display = 'block';
    });

    // Function to open the download ticket popup
    function openTicketPopup() {
        // Display the download ticket popup
        document.getElementById('popup-overlay').style.display = 'block';
        document.getElementById('download-ticket-popup').style.display = 'block';

        // Fetch ticket details using AJAX
        var userId = <?php echo $userData['user_id']; ?>;
        fetch('get_ticket.php?user_id=' + userId)
            .then(response => response.json())
            .then(data => {
                if (data.status === 'success' && data.tickets) {
                    // Display ticket details in the modal
                    populateTicketDetails(data.tickets);
                } else {
                    // Display an error message
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
    }

    // Function to populate ticket details in the ticket popup
    function populateTicketDetails(tickets) {
        // Create a container for all tickets
        var ticketsContainer = document.getElementById('ticket-details');
        ticketsContainer.innerHTML = '';

        // Iterate over each ticket and create formatted HTML
        tickets.forEach(ticket => {
            var ticketHTML = `
                <div class="ticket">
                    <div class="ticket-left">
                        <p class="ticket-heading">Soccer Match Ticket</p>
                        <p class="ticket-info">Gate#: ${ticket.gate_id}</p>
                        <p class="ticket-info">Seat: R${ticket.seat_row}, C${ticket.seat_col}</p>
                        <p class="ticket-info">Booker: ${ticket.booker_name}</p>
                        <p class="ticket-info">Class: ${ticket.seat_class}</p>
                        <p class="ticket-info">Match ID: ${ticket.match_id}</p>
                        <p class="ticket-price">Price: $${ticket.total}</p>
                    </div>
                    <div class="ticket-right">
                        <div class="qr-code"></div> <!-- Add a div for QR code -->
                    </div>
                </div>
            `;

            // Append the ticket HTML to the container
            ticketsContainer.innerHTML += ticketHTML;
        });
    }

    // Function to close the download ticket popup
    function closeTicketPopup() {
        // Close the download ticket popup
        document.getElementById('popup-overlay').style.display = 'none';
        document.getElementById('download-ticket-popup').style.display = 'none';
    }

    // Function to handle the download ticket form submission
    function downloadTicket(event) {
        event.preventDefault();

        // Perform any additional actions needed for downloading the ticket
        // (e.g., trigger a download, open a new window, etc.)

        // Close the download ticket popup
        closeTicketPopup();
    }

    // Attach click event to the "Print Ticket" button
    document.getElementById('print-ticket-btn').addEventListener('click', openTicketPopup);

    // Function to open the popup
    function openPopup() {
        // Check if seats are selected
        var selectedSeats = document.querySelectorAll('.table-container .seat-checkbox:checked');
        if (selectedSeats.length === 0) {
            alert('Please select at least one seat before booking.');
            return;
        }

        document.getElementById('popup-overlay').style.display = 'block';
        document.getElementById('booking-popup').style.display = 'block';
    }

    // Function to close the popup and reset selected seats
    function closePopup() {
        // Deselect all checkboxes
        var allCheckboxes = document.querySelectorAll('.table-container .seat-checkbox');
        allCheckboxes.forEach(function (checkbox) {
            checkbox.checked = false;
        });

        // Update the selected seats information
        updateSelectedSeats();

        // Close the popup
        document.getElementById('popup-overlay').style.display = 'none';
        document.getElementById('booking-popup').style.display = 'none';
    }

    // Function to submit the form for seat booking
    function submitForm(event) {
        event.preventDefault();

        // Get selected seats information
        var selectedSeatsInfo = JSON.parse(document.getElementById('selected-seats-ids').value);

        // Create a FormData object to serialize the form data
        var formData = new FormData(document.getElementById('booking-form'));
        formData.append('selected-seats-ids', JSON.stringify(selectedSeatsInfo));

        // Perform AJAX request to submit the form data
        fetch('submit_bookings.php', {
                method: 'POST',
                body: formData,
            })
            .then(response => response.json())
            .then(data => {
                // Log the response data to the console
                console.log(data);

                // Check if the submission was successful
                if (data.status === 'success') {
                    // Optionally, display a success message to the user
                    alert(data.message);
                } else {
                    // Display an error message to the user
                    alert('Error: ' + data.message);
                }
            })
            .catch(error => {
                console.error('Error:', error);
            })
            .finally(() => {
                // After successful or unsuccessful submission, close the popup
                closePopup();
            });
    }

    // Event listeners
    document.getElementById('book-seats-btn').addEventListener('click', openPopup);
    document.getElementById('close-popup-btn').addEventListener('click', closePopup);
    document.getElementById('booking-form').addEventListener('submit', submitForm);

    // Function to toggle seat selection
    function toggleSeatSelection(cell) {
        cell.classList.toggle('selected-seat');
    }

    // Function to get row and column numbers from data-id
    function getRowAndCol(cell) {
        var seatId = cell.getAttribute('data-id');
        var [row, col] = seatId.split('-').map(Number);
        return { row, col };
    }

    // Function to update the selected seats information and total amount
    function updateSelectedSeats() {
        var selectedSeatsInfo = [];

        // Select all checkboxes within the table
        var allCheckboxes = document.querySelectorAll('.table-container .seat-checkbox');

        allCheckboxes.forEach(function (checkbox) {
            if (checkbox.checked) {
                var cell = checkbox.closest('.seat');
                var { row, col } = getRowAndCol(cell);
                selectedSeatsInfo.push({ row, col });
            }
        });

        // Update the display
        var displayList = document.getElementById('selected-seats-display');
        displayList.innerHTML = '';

        var totalAmountField = document.getElementById('total_amount');
        var totalAmount = calculateTotalAmount(selectedSeatsInfo);

        if (selectedSeatsInfo.length > 0) {
            selectedSeatsInfo.forEach(function (seat) {
                var listItem = document.createElement('li');
                listItem.textContent = `Row: ${seat.row}, Column: ${seat.col}`;
                displayList.appendChild(listItem);
            });
        } else {
            var listItem = document.createElement('li');
            listItem.textContent = 'No seats selected';
            displayList.appendChild(listItem);
        }

        // Update the hidden field value
        document.getElementById('selected-seats-ids').value = JSON.stringify(selectedSeatsInfo);

        // Update the total amount field
        totalAmountField.value = `{totalAmount}`;
    }

    // Function to calculate the total amount based on seat prices
    function calculateTotalAmount(seats) {
        var totalAmount = 0;

        seats.forEach(function (seat) {
            // Check the class of the seat and add the corresponding price
            if (seat.row >= 0 && seat.row <= 2 && seat.col >= 0 && seat.col <= 14) {
                totalAmount += seatPrices.frontClass;
            } else if (seat.row >= 12 && seat.row <= 14 && seat.col >= 0 && seat.col <= 14) {
                totalAmount += seatPrices.middleClass;
            } else {
                totalAmount += seatPrices.ordinaryClass;
            }
        });

        return totalAmount;
    }

    // Event listener for seat clicks
    document.querySelector('.table-container').addEventListener('change', function (event) {
        var target = event.target;
        if (target.classList.contains('seat-checkbox')) {
            // Update the selected seats information
            updateSelectedSeats();
        }
    });

    // Function to handle the submission of step 1
    function submitStep1(event) {
        // Handle submission of step 1
        event.preventDefault();
        // Additional logic for step 1 submission
        nextStep(); // Move to step 2
    }

    // Function to handle the submission of step 2
    function submitStep2(event) {
        // Handle submission of step 2
        event.preventDefault();
        // Additional logic for step 2 submission
        closePopup(); // Close the popup after submission
    }

    // Function to move to the next step
    function nextStep() {
        if (currentStep === 1) {
            document.getElementById('booking-popup').style.display = 'none';
            document.getElementById('momo-payment-popup').style.display = 'block';
            currentStep = 2;
        }
    }

    // Function to close the popup
    function closePopup() {
        document.getElementById('popup-overlay').style.display = 'none';
        document.getElementById('booking-popup').style.display = 'none';
        document.getElementById('momo-payment-popup').style.display = 'none';
        currentStep = 1;
    }

    // Display the initial step when the page loads
    document.getElementById('popup-overlay').style.display = 'none';
    document.getElementById('booking-popup').style.display = 'none';

</script>
<!-- Rest of your HTML code -->


<script src="https://html2canvas.hertzen.com/dist/html2canvas.js"></script>


</body>

</html>
