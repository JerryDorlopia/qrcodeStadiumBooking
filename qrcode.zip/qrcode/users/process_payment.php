<?php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get Momo Number and total amount from the form
    $momoNumber = $_POST['momo_number'];
    $totalAmount = $_POST['total_amount'];

    // Generate a unique transaction token
    $txToken = 'TX' . uniqid();

    // Ngrok callback URL
    $ngrokCallbackURL = 'https://0b05-41-186-78-59.ngrok-free.app/qrcode/users/process_payment.php'; // Replace with your actual ngrok URL

    // Prepare JSON data for the API request with ngrok callback URL
    $jsonData = json_encode([
        'action' => 'pay',
        'auth' => '37f69d1750c189c8ad77a717fa957d9eaebcac16', // Replace with your actual auth token
        'tx' => $txToken,
        'amo' => $totalAmount,
        'currency' => 'rwf',
        'tel' => $momoNumber,
        'withcha' => 'Y',
        'note' => 'This is a test',
        'callback' => $ngrokCallbackURL,
    ]);

    // Create stream context for the API request
    $context = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => "Content-Type: application/json\r\n",
            'content' => $jsonData,
        ],
    ]);

    // Make the API request
    $apiUrl = 'https://cashnayo.com/api/v1/';
    $response = file_get_contents($apiUrl, false, $context);

    // Handle the API response
    if ($response === false) {
        // Error handling
        echo 'Error making API request';
    } else {
        $responseData = json_decode($response, true);

        // Display the API response in a popup form with styles
        echo '<!DOCTYPE html>
            <html lang="en">
            <head>
                <meta charset="UTF-8">
                <meta name="viewport" content="width=device-width, initial-scale=1.0">
                <title>API Response Popup</title>
                <style>
                    body {
                        font-family: Arial, sans-serif;
                        margin: 0;
                        padding: 0;
                        display: flex;
                        align-items: center;
                        justify-content: center;
                        height: 100vh;
                        background: #f4f4f4;
                    }

                    .popup {
                        background: #fff;
                        padding: 20px;
                        border-radius: 8px;
                        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
                        text-align: center;
                    }

                    .close-btn {
                        margin-top: 10px;
                        padding: 8px 16px;
                        background: #007BFF;
                        color: #fff;
                        border: none;
                        border-radius: 4px;
                        cursor: pointer;
                    }
                </style>
            </head>
            <body>
                <div class="popup">
                    <p>';

        if ($responseData && isset($responseData['code']) && $responseData['code'] === '110' && isset($responseData['status']) && $responseData['status'] === 'request accepted') {
            // If the request is accepted
            echo 'Payment has been initiated. Please confirm the payment on your phone to proceed. Transaction ID: ' . $txToken;
        } else {
            // If the request is not accepted
            echo 'Error processing payment.';
        }

        echo '</p>
                    <button class="close-btn" onclick="closePopup()">Close</button>
                </div>

                <script>
                    // Function to close the popup
                    function closePopup() {
                        document.querySelector(".popup").style.display = "none";
                    }
                </script>
            </body>
            </html>';
    }
}
?>
