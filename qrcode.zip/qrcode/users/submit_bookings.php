<?php
session_start();

// Check if the user is not logged in, redirect to login page
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qrcodegen";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Initialize response array
$response = array();

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Fetch user_id from the session
    $user_id = $_SESSION['user_id'];

    // Validate and sanitize input
    $selectedSeatsInfo = isset($_POST['selected-seats-ids']) ? json_decode($_POST['selected-seats-ids'], true) : null;
    $bookerName = isset($_POST['booker_name']) ? mysqli_real_escape_string($conn, $_POST['booker_name']) : null;
    $bookerEmail = isset($_POST['booker_email']) ? mysqli_real_escape_string($conn, $_POST['booker_email']) : null;
    $bookerPhone = isset($_POST['booker_phone']) ? mysqli_real_escape_string($conn, $_POST['booker_phone']) : null;
    $selectedGate = isset($_POST['selected-gate']) ? mysqli_real_escape_string($conn, $_POST['selected-gate']) : null;

    // Additional hidden fields
    $selectedEventId = isset($_POST['selectedEventId']) ? $_POST['selectedEventId'] : null;
    $selectedTeam1 = isset($_POST['selectedTeam1']) ? mysqli_real_escape_string($conn, $_POST['selectedTeam1']) : null;
    $selectedTeam2 = isset($_POST['selectedTeam2']) ? mysqli_real_escape_string($conn, $_POST['selectedTeam2']) : null;
    $eventTitle = isset($_POST['eventTitle']) ? mysqli_real_escape_string($conn, $_POST['eventTitle']) : null;
    $matchDate = isset($_POST['matchDate']) ? $_POST['matchDate'] : null;
    $eventStartTime = isset($_POST['eventStartTime']) ? $_POST['eventStartTime'] : null;
    $eventEndTime = isset($_POST['eventEndTime']) ? $_POST['eventEndTime'] : null;

    // Check if required fields are set
    if ($selectedSeatsInfo !== null && $bookerName !== null && $bookerEmail !== null && $bookerPhone !== null && $selectedGate !== null) {
        // Insert data into the 'bookings' table
        foreach ($selectedSeatsInfo as $seat) {
            $seatRow = $seat['row'];
            $seatCol = $seat['col'];

            // Determine the class of the seat
            $seatClass = '';
            if ($seatRow >= 0 && $seatRow <= 2 && $seatCol >= 0 && $seatCol <= 20) {
                $seatClass = 'gold-front-class';
                $seatPrice = 8;
            } elseif ($seatRow >= 12 && $seatRow <= 14 && $seatCol >= 0 && $seatCol <= 20) {
                $seatClass = 'middle-class';
                $seatPrice = 6;
            } else {
                $seatClass = 'cream-class';
                $seatPrice = 4;
            }

            // Calculate total amount
            $total = $seatPrice;

            // SQL query to insert data into the 'bookings' table
            $sql = "INSERT INTO bookings (user_id, gate_id, seat_row, seat_col, booker_name, booker_email, booker_phone, seat_class, total, 
                    selectedTeam1, selectedTeam2, selectedEventId, eventTitle, matchDate, eventStartTime, eventEndTime)
                    VALUES ($user_id, '$selectedGate', $seatRow, $seatCol, '$bookerName', '$bookerEmail', '$bookerPhone', '$seatClass', $total, 
                    '$selectedTeam1', '$selectedTeam2', $selectedEventId, '$eventTitle', '$matchDate', '$eventStartTime', '$eventEndTime')";

            if ($conn->query($sql) === TRUE) {
                $response['status'] = 'success';
                $response['message'] = 'Booking successful!';
            } else {
                $response['status'] = 'error';
                $response['message'] = 'Error: ' . $sql . '<br>' . $conn->error;
            }
        }
    } else {
        $response['status'] = 'error';
        $response['message'] = 'Invalid or missing input data';
    }
} else {
    $response['status'] = 'error';
    $response['message'] = 'Invalid request method';
}

// Close the database connection
$conn->close();

// Send JSON response
header('Content-Type: application/json');
echo json_encode($response);
?>
