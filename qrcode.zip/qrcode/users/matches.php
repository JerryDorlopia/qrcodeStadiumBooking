<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <title>Soccer Matches</title>
    <style>
   body {
    font-family: Arial, sans-serif;
    margin: 0;
    padding: 0;
    background-color: #ecedf0;
}

header {
    background-color: #fff;
    color: #333;
    padding: 10px;
    position: fixed;
    width: 100%;
    top: 0;
    z-index: 1000;
}

.header-content {
    display: flex;
    justify-content: space-between;
    align-items: center;
    max-width: 1200px;
    margin: 0 auto;
}

.logo img {
    height: 30px; /* Adjust as needed */
    margin-right:200px;
}

h1 {
    margin: 0;
}

nav ul {
    list-style: none;
    margin: 0;
    padding: 0;
    display: flex;
}

nav li {
    margin-right: 20px;
}

nav a {
    text-decoration: none;
    color: #333;
    font-weight: bold;
    font-size: 16px;
    display: flex;
    align-items: center;
}

nav a i {
    margin-right: 5px;
}

nav a:hover {
    color: #4caf50; /* Change the color on hover */
}

        
        .page-wrapper {
            background-color: #fff;
            border-radius: 10px;
            overflow: hidden;
            max-width: 1200px; /* Reduced the width of the page */
            margin: auto; /* Center the page */
            
        }
        .flex-container {
            display: flex;
            flex-wrap: wrap;
            margin: 20px;
            margin-bottom: 50px;
        }
        .col {
            flex: 1;
        }
        .search-container {
            text-align: center;
            margin: 20px;
            width:500px;
            margin-left:20px;


        }
        .search-container form {
            display: flex;
            justify-content: flex-end;
            

        }
        input[type="text"] {
            padding: 10px;
            flex-grow: 1;
            border-radius: 50px 0px 0px 50px;
            border:none;

        }
        input[type="submit"] {
            padding: 10px;
            background-color: #4caf50;
            color: white;
            border-radius:  0px 50px 50px 0px;
            border: none;
            cursor: pointer;
            width:100px;

        }
        .slider-container {
    max-width: 600px;
    margin-right: 20px; /* Adjusted margin */
    overflow: hidden;
    margin-left: 30px;
    border-radius: 20px;

    /* Add glow shadow with blue and green */
    box-shadow: 0 0 5px #ffeb3b, 0 0 10px green;

    /* Television frame styling */
    border: 10px solid #ccc; /* Adjust border thickness and color */
    background-color: #ecedf0; /* Adjust background color to match the television screen */
    position: relative;
}

/* Add some padding to simulate the screen content */
.slider-container .slider {
    padding: 20px; /* Adjust as needed */
}

/* Example styling for .slider content (adjust as needed) */
.slider img {
    width: 100%;
    height: auto;
}



        .slider {
            display: flex;
            transition: transform 0.5s ease-in-out;
            animation: changeImage 20s infinite;
        }
        
        .advertisement-container {
            max-width: 480px;
            overflow: hidden;
            text-align: center;
            background-color: #f0f0f0;
            border-radius: 5px;
        }
        .advertisement {
            padding: 10px;
        }
        .match-container {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
            margin: 1px;
        }
/* Add the following CSS for typing effect */
.advertisement p {
    overflow: hidden;
    white-space: nowrap;
    animation: typing 4s steps(40) forwards;
}

@keyframes typing {
    from {
        width: 0;
    }
    to {
        width: 100%;
    }
}



        .match img {
            width: 100%;
            height: auto;
            margin-bottom: 5px;
            border-radius: 20px 0px;
        }
        .book-button {
            background-color: #0c96f1;
            color: white;
            padding: 8px 16px;
            text-decoration: none;
            display: inline-block;
            font-size: 14px;
            margin-top: 10px;
            border-radius:5px;
        }
        @keyframes changeImage {
            0% {
                transform: translateX(0);
            }
            20% {
                transform: translateX(0);
            }
            25% {
                transform: translateX(-100%);
            }
            45% {
                transform: translateX(-100%);
            }
            50% {
                transform: translateX(-200%);
            }
            70% {
                transform: translateX(-200%);
            }
            75% {
                transform: translateX(-300%);
            }
            95% {
                transform: translateX(-300%);
            }
            100% {
                transform: translateX(0);
            }
        }

        .flex-container {
    display: flex;
    justify-content: space-between; /* Adjust as needed */
}

.match {
    background-color: #fff;
    margin-bottom: 20px; /* Adjust as needed */
    width: 24%; /* Adjust as needed */
    text-align: center;
    border-radius: 20px 0;
    box-shadow: 0 0 10px rgba(0, 0, 0, 0.5); /* Add shadow effect */
    position: relative;
    transition: transform 0.3s ease-in-out;

}
.match:before {
    content: '';
    position: absolute;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    border-radius: 20px;
    z-index: -1;
    transition: opacity 0.3s ease-in-out; /* Add transition effect */
}
.match:hover {
    transform: scale(1.05); /* Add scale effect on hover */
}

.match:hover:before {
    opacity: 0.5; /* Reduce the opacity on hover */
}
.flex-container-date {
    display: flex;
    margin-left:25px;

   
}

.flex-col {
    text-align: center;
    margin: 5px 5px; /* Add margin between elements */
}

.flex-col p {
    margin: 0;
}





.small-text {
    font-size: 11px; /* Adjust as needed */
}
.team-info{
    font-size:15px;
}

/* Update the CSS for the footer */
footer {
    background-color:  #0c96f1;
    color: #fff;
    padding: 10px 0;
    text-align: center;
}

.footer-content {
    max-width: 1200px;
    margin: 0 auto;
    display: flex;
    flex-direction: column;
    align-items: center;
}

.social-icons {
    margin-top: 10px;
}

.social-icons a {
    color: #fff;
    margin: 0 10px;
    font-size: 20px;
    text-decoration: none;
}

.social-icons a:hover {
    color: #4caf50; /* Change the color on hover */
}















/* Add a media query for responsiveness */
@media only screen and (max-width: 768px) {
    header {
        padding: 5px;
    }

    .logo img {
        margin-right: 0;
    }

    nav ul {
        flex-direction: column;
        align-items: flex-end;
    }

    nav li {
        margin: 5px 0;
    }

    .search-container {
        width: 100%;
        margin-left: 0;
    }

    .flex-container {
        margin: 10px;
        margin-bottom: 30px;
    }

    .col {
        flex: 100%;
    }

    .slider-container,
    .advertisement-container {
        max-width: 100%;
        margin: 0;
    }

    .slider-container {
        margin-left: 10px;
        margin-right: 10px;
    }

    .search-container form {
        justify-content: center;
    }

    input[type="text"] {
        border-radius: 50px;
        border: none;
    }

    input[type="submit"] {
        width: 100%;
        border-radius: 50px;
    }

    .match {
        width: 100%;
    }

    .footer-content {
        text-align: center;
    }
}

/* Rest of the existing styles */
/* ... */

    </style>
</head>
<body> 
<header>
    <div class="header-content">
        <div class="logo">
            <img src="uploads/ticket-logo.png" alt="Logo">
        </div>
        <nav>
            <ul>
                <li><a href="#"><i class="fas fa-home"></i> Home</a></li>
                <li><a href="#"><i class="fas fa-futbol"></i> Matches</a></li>
                <li><a href="#"><i class="fas fa-info-circle"></i> About</a></li>
                <li><a href="#"><i class="fas fa-user"></i> Login</li>

                <!-- Add more menu items as needed -->
            </ul>
        </nav>
        
    <div class="col search-container">
                <form method="GET" action="">
                    <input type="text" name="search" placeholder="Search by keyword">
                    <input type="submit" value="Search">
                </form>
            </div></div>
</header>
        <br><br><br><br><br><br>
    <div class="page-wrapper">
       
        <div class="flex-container">
            <!-- Add a search bar -->
            
            <!-- Add the slider container -->
            <div class="col slider-container">
                <div class="slider">
                    <?php
                        $conn = new mysqli("localhost", "root", "", "qrcodegen");

                        if ($conn->connect_error) {
                            die("Connection failed: " . $conn->connect_error);
                        }

                        // Fetch random event images
                        $sqlSlider = "SELECT event_id, event_image FROM pref_event ORDER BY RAND() LIMIT 5";
                        $resultSlider = $conn->query($sqlSlider);

                        if ($resultSlider->num_rows > 0) {
                            while ($rowSlider = $resultSlider->fetch_assoc()) {
                                echo '<img src="../' . $rowSlider["event_image"] . '" alt="Slider Image">';
                            }
                        }
                    ?>
                </div>
            </div>
            <!-- Add advertisement container -->
            <div class="col advertisement-container">
                <div class="advertisement">
                    <br><br><br><br>
                    <p id="advertisementText"></p>
                </div>
            </div>

            
            </div>
            <div class="mpage-wrapper">

        <div class="match-container">
            <?php
                // Connect to the database
                $servername = "localhost";
                $username = "root";
                $password = "";
                $dbname = "qrcodegen";

                $conn = new mysqli($servername, $username, $password, $dbname);

                // Check connection
                if ($conn->connect_error) {
                    die("Connection failed: " . $conn->connect_error);
                }

                // Hide events where event_end_time is greater than the current time
                $currentTime = date('Y-m-d H:i:s');
                $sqlHideEvents = "UPDATE pref_event SET event_end_time = NULL WHERE event_end_time > '$currentTime'";
                $conn->query($sqlHideEvents);

                // Check if the search form is submitted
                if (isset($_GET['search'])) {
                    $keyword = $_GET['search'];

                    // Fetch events from the database based on the keyword
                    $sql = "SELECT * FROM pref_event 
                            WHERE event_title LIKE '%$keyword%' OR team1 LIKE '%$keyword%' OR team2 LIKE '%$keyword%'";
                } else {
                    // Fetch all events if no search keyword is provided
                    $sql = "SELECT * FROM pref_event";
                }

                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    // Output data of each row
                    echo '<div class="flex-container">';

                    while ($row = $result->fetch_assoc()) {
                        echo '<div class="match">';
                        
                        // Add a style attribute to set the width and height of the image
                        echo '<img src="../' . $row["event_image"] . '" alt="' . $row["event_title"] . ' Image" style="width: 260px; height: 120px;">';
                    
                        echo '<h2 style="font-size:18px">' . $row["event_title"] . '</h2>';
                        echo '<p class="team-info">' . $row["team1"] . ' vs ' . $row["team2"] . '</p>';
                        
                        echo '<div class="flex-container-date">';
                        
                        // Date section with icon
                        echo '<div class="flex-col">';
                        echo '<p style="color:green" class="small-text"><i class="fas fa-calendar-alt"></i> Date:</p>';
                        echo '<p style="color:#666" class="small-text">' . $row["match_date"] . '</p>';
                        echo '</div>';
                        
                        echo '<div class="flex-col">';
                        echo '<p class="small-text">|</p>';
                        echo '</div>';
                        
                        // Start Time section with icon
                        echo '<div class="flex-col">';
                        echo '<p style="color:#0c96f1" class="small-text"><i class="fas fa-clock"></i> Start Time:</p>';
                        echo '<p style="color:#666" class="small-text">' . $row["event_start_time"] . '</p>';
                        echo '</div>';
                        
                        echo '<div class="flex-col">';
                        echo '<p class="small-text">|</p>';
                        echo '</div>';
                        
                        // End Time section with icon
                        echo '<div class="flex-col">';
                        echo '<p style="color:orange" class="small-text"><i class="fas fa-clock"></i> End Time:</p>';
                        echo '<p style="color:#666" class="small-text">' . $row["event_end_time"] . '</p>';
                        echo '</div>';
                        
                        echo '</div>';
                        
                       // Booking button
        echo '<a href="#" class="book-button" data-event-id="' . $row["event_id"] . '" data-team1="' . $row["team1"] . '" data-team2="' . $row["team2"] . '" onclick="submitForm(' . $row["event_id"] . ', \'' . $row["team1"] . '\', \'' . $row["team2"] . '\', \'' . $row["event_title"] . '\', \'' . $row["match_date"] . '\', \'' . $row["event_start_time"] . '\', \'' . $row["event_end_time"] . '\')">Book your Seat Now</a>';
        echo '</div>';
                        
                    }
                    

                echo '</div>';

                    
                }
                // Close the database connection
                $conn->close();
            ?>
        </div>
<!-- Hidden fields to store selected event_id and team information -->
<input type="hidden" id="selectedEventId" name="selectedEventId" value="">
<input type="hidden" id="selectedTeam1" name="selectedTeam1" value="">
<input type="hidden" id="selectedTeam2" name="selectedTeam2" value="">
<!-- Additional hidden fields for event information -->
<input type="hidden" id="eventTitle" name="eventTitle" value="">
<input type="hidden" id="matchDate" name="matchDate" value="">
<input type="hidden" id="eventStartTime" name="eventStartTime" value="">
<input type="hidden" id="eventEndTime" name="eventEndTime" value="">
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        /* Center the popup */
        #confirmationPopup {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: white;
            padding: 40px;
            border: 1px solid #ccc;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            z-index: 1000;
            text-align: center;
        }

        /* Style the OK button */
        #okButton {
            padding: 10px 20px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            margin-top: 20px;
        }

        /* Style the close button */
        #closeButton {
            position: absolute;
            top: 10px;
            right: 10px;
            font-size: 18px;
            cursor: pointer;
        }
    </style>
</head>
<body>

    <script>
        function submitForm(eventId, team1, team2, eventTitle, matchDate, eventStartTime, eventEndTime) {
            // Set values to hidden fields
            document.getElementById('selectedEventId').value = eventId;
            document.getElementById('selectedTeam1').value = team1;
            document.getElementById('selectedTeam2').value = team2;
            document.getElementById('eventTitle').value = eventTitle;
            document.getElementById('matchDate').value = matchDate;
            document.getElementById('eventStartTime').value = eventStartTime;
            document.getElementById('eventEndTime').value = eventEndTime;

            var confirmationMessage = 'You have selected:<br><br>' +
                'Event: ' + eventTitle + '<br><br>' + 
                'Team 1: ' + team1 + '<br><br>' + 
                'Team 2: ' + team2 + '<br>';
            
            // Create a popup element
            var confirmationPopup = document.createElement('div');
            confirmationPopup.id = 'confirmationPopup';
            confirmationPopup.innerHTML = confirmationMessage;

            // Create the close button (X)
            var closeButton = document.createElement('span');
            closeButton.id = 'closeButton';
            closeButton.innerHTML = '&times;'; // Times symbol (X)

            // Add an event listener to the close button to hide the popup
            closeButton.addEventListener('click', function() {
                confirmationPopup.style.display = 'none';
            });

            // Append the close button to the popup
            confirmationPopup.appendChild(closeButton);

            // Create the OK button
            var okButton = document.createElement('button');
            okButton.id = 'okButton';
            okButton.innerText = 'OK';

            // Add an event listener to the OK button
            okButton.addEventListener('click', function() {
                // Create a form element
                var form = document.createElement('form');
                form.method = 'POST';
                form.action = 'login.php';

                // Create hidden input fields
                var eventIdInput = createHiddenInput('selectedEventId', eventId);
                var team1Input = createHiddenInput('selectedTeam1', team1);
                var team2Input = createHiddenInput('selectedTeam2', team2);
                var eventTitleInput = createHiddenInput('eventTitle', eventTitle);
                var matchDateInput = createHiddenInput('matchDate', matchDate);
                var eventStartTimeInput = createHiddenInput('eventStartTime', eventStartTime);
                var eventEndTimeInput = createHiddenInput('eventEndTime', eventEndTime);

                // Append hidden fields to the form
                form.appendChild(eventIdInput);
                form.appendChild(team1Input);
                form.appendChild(team2Input);
                form.appendChild(eventTitleInput);
                form.appendChild(matchDateInput);
                form.appendChild(eventStartTimeInput);
                form.appendChild(eventEndTimeInput);

                // Append the form to the document body
                document.body.appendChild(form);

                // Submit the form
                form.submit();
            });

            // Append the OK button to the popup
            confirmationPopup.appendChild(okButton);

            // Append the popup element to the body
            document.body.appendChild(confirmationPopup);

            // Display the confirmation popup
            confirmationPopup.style.display = 'block';
        }

        function createHiddenInput(name, value) {
            var input = document.createElement('input');
            input.type = 'hidden';
            input.name = name;
            input.value = value;
            return input;
        }
    </script>
</body>
</html>




    </div>

    <!-- Add this at the end of your HTML body -->
<footer>
    <div class="footer-content">
        <p>&copy; 2023 MyTikay. All rights reserved.</p>
        <div class="social-icons">
            <a href="#" target="_blank"><i class="fab fa-facebook"></i></a>
            <a href="#" target="_blank"><i class="fab fa-twitter"></i></a>
            <a href="#" target="_blank"><i class="fab fa-instagram"></i></a>
        </div>
    </div>
</footer>
<script>
    document.addEventListener("DOMContentLoaded", function () {
        var advertisementTexts = [
            "Have Something to share with the world? ",
            "Place your Advertisement Here!",
            "It's Easy, Just Contact us",
            "email: garjayebeah@gmail.com ",
            "Phone: +2317705398 ",
            "My Tikay is a Liberian owned business ",


            // Add more texts as needed
        ];

        var advertisementElement = document.getElementById("advertisementText");

        function typeText(index) {
            var currentText = advertisementTexts[index % advertisementTexts.length];
            var currentIndex = 0;

            function animateText() {
                if (currentIndex <= currentText.length) {
                    advertisementElement.textContent = currentText.slice(0, currentIndex);
                    currentIndex++;
                    setTimeout(animateText, 100);
                } else {
                    setTimeout(function () {
                        typeText(index + 1); // Move to the next text
                    }, 2000); // Wait for 40 seconds
                }
            }

            animateText();
        }

        typeText(0);
    });
</script>


</body>
</html>
