<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "qrcodegen";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve booked seats from the database
$result = $conn->query("SELECT seat_row, seat_col FROM bookings");
$bookedSeats = [];
while ($row = $result->fetch_assoc()) {
    $bookedSeats[] = $row;
}

// Close the database connection
$conn->close();

// Return booked seats as JSON
echo json_encode($bookedSeats);
?>
