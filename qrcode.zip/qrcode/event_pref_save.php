<?php
include('session.php');

// Error reporting for debugging purposes
error_reporting(E_ALL);
ini_set('display_errors', 1);

if (isset($_POST['add_event_pref'])) {
    $event_title = $_POST['event_title'];
    $event_venue = $_POST['event_venue'];
    $team1 = $_POST['team1'];
    $team2 = $_POST['team2'];
    $match_date = $_POST['match_date'];
    $event_start_time = $_POST['event_start_time'];
    $event_end_time = $_POST['event_end_time'];

    // File upload logic
    $targetDir = "images/";
    $targetFile = $targetDir . basename($_FILES["event_image"]["name"]);    
    $uploadOk = 1;
    $imageFileType = strtolower(pathinfo($targetFile, PATHINFO_EXTENSION));

    // Check if image file is a valid image
    $check = getimagesize($_FILES["event_image"]["tmp_name"]);
    if ($check === false) {
        echo '<script>window.alert("File is not an image.");</script>';
        $uploadOk = 0;
    }

    // Check file size
    if ($_FILES["event_image"]["size"] > 500000) {
        echo '<script>window.alert("Sorry, your file is too large.");</script>';
        $uploadOk = 0;
    }

    // Allow certain file formats
    $allowedFormats = ["jpg", "jpeg", "png", "gif", "jfif"];
    if (!in_array($imageFileType, $allowedFormats)) {
        echo '<script>window.alert("Sorry, only JPG, JPEG, JFIF, PNG & GIF files are allowed.");</script>';
        $uploadOk = 0;
    }

    // Move uploaded file to target directory if all checks pass
if ($uploadOk == 1 && move_uploaded_file($_FILES["event_image"]["tmp_name"], $targetFile)) {
    // Assuming your database columns are named accordingly
    $conn->query("INSERT INTO pref_event (event_title, event_venue, team1, team2, match_date, event_image, event_start_time, event_end_time)
        VALUES ('$event_title', '$event_venue', '$team1', '$team2', '$match_date', '$targetFile', '$event_start_time', '$event_end_time')");

    echo '<script>window.alert("Event ' . $event_title . ' (' . $match_date . ' | ' . $event_venue . ') successfully added.");</script>';
    echo '<script>window.location="event_list.php";</script>';
} else {
    echo '<script>window.alert("Sorry, there was an error uploading your file.");</script>';
}

}   


if (isset($_POST['updateEventModal'])) {
    $event_title = $_POST['event_title'];
    $event_venue = $_POST['event_venue'];
    $team1 = $_POST['team1'];
    $team2 = $_POST['team2'];
    $match_date = $_POST['match_date'];
    $event_id = $_POST['event_id'];

    $queryResult = $conn->query("UPDATE pref_event SET event_title='$event_title', event_venue='$event_venue', team1='$team1', team2='$team2', match_date='$match_date' WHERE event_id='$event_id'");

    if ($queryResult) {
        echo '<script>alert("Success: Event ' . $event_title . ' (' . $match_date . ' | ' . $event_venue . ') successfully updated.");</script>';
        echo '<script>window.location="event_list.php";</script>';
    } else {
        echo '<script>alert("Error: Failed to update event. Please try again.");</script>';
    }
}

if (isset($_POST['delete_event_pref'])) {
    $event_id = $_POST['event_id'];

    $queryResult = $conn->query("DELETE FROM pref_event WHERE event_id='$event_id'");

    if ($queryResult) {
        echo '<script>alert("Success: Event successfully deleted.");</script>';
        echo '<script>window.location="event_list.php";</script>';
    } else {
        echo '<script>alert("Error: Failed to delete event. Please try again.");</script>';
    }
}

?>
