-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 18, 2023 at 12:02 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `qrcodegen`
--

-- --------------------------------------------------------

--
-- Table structure for table `booked_seats`
--

CREATE TABLE `booked_seats` (
  `booking_id` int(11) NOT NULL,
  `seat_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bookings`
--

CREATE TABLE `bookings` (
  `id` int(11) NOT NULL,
  `seat_row` int(11) DEFAULT NULL,
  `seat_col` int(11) DEFAULT NULL,
  `booker_name` varchar(255) DEFAULT NULL,
  `booker_email` varchar(255) DEFAULT NULL,
  `booker_phone` varchar(20) DEFAULT NULL,
  `total` decimal(10,2) DEFAULT 0.00,
  `seat_class` varchar(255) NOT NULL DEFAULT 'cream-class',
  `user_id` int(11) NOT NULL,
  `gate_id` int(11) NOT NULL,
  `eventTitle` varchar(255) NOT NULL,
  `eventStartTime` time NOT NULL,
  `eventEndTime` time NOT NULL,
  `selectedEventid` int(11) NOT NULL DEFAULT 0,
  `selectedTeam1` varchar(255) NOT NULL,
  `selectedTeam2` varchar(255) NOT NULL,
  `matchDate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bookings`
--

INSERT INTO `bookings` (`id`, `seat_row`, `seat_col`, `booker_name`, `booker_email`, `booker_phone`, `total`, `seat_class`, `user_id`, `gate_id`, `eventTitle`, `eventStartTime`, `eventEndTime`, `selectedEventid`, `selectedTeam1`, `selectedTeam2`, `matchDate`) VALUES
(141, 2, 1, 'JERRY DORLOPIA', 'goldfingerjd@gmail.com', '+250790064067', 8.00, 'gold-front-class', 1, 5, 'International Friendly', '19:51:00', '00:00:00', 14, 'Nimba', 'Montserrado', '2023-12-21');

-- --------------------------------------------------------

--
-- Table structure for table `pref_event`
--

CREATE TABLE `pref_event` (
  `event_id` int(11) NOT NULL,
  `event_title` varchar(255) NOT NULL,
  `event_date` varchar(255) NOT NULL,
  `event_venue` varchar(255) NOT NULL,
  `team1` varchar(255) NOT NULL,
  `team2` varchar(255) NOT NULL,
  `match_date` varchar(255) NOT NULL,
  `event_image` varchar(255) NOT NULL,
  `event_start_time` time NOT NULL,
  `event_end_time` time NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `pref_event`
--

INSERT INTO `pref_event` (`event_id`, `event_title`, `event_date`, `event_venue`, `team1`, `team2`, `match_date`, `event_image`, `event_start_time`, `event_end_time`) VALUES
(8, 'International Friendly', '', 'SKD', 'Mali', 'Liberia', '2023-12-29', 'images/match.png', '05:00:00', '06:24:00'),
(9, 'National County Sports Meet', '', 'SKD', 'LOFA', 'NIMBA', '2023-12-22', 'images/images (5).jfif', '07:09:00', '00:00:00'),
(10, 'National County Sports Meet', '', 'SKD', 'Bong', 'Margibi', '2023-12-29', 'images/images (6).jfif', '03:29:00', '00:00:00'),
(11, 'National County Sports Meet', '', 'SKD', 'Margibi', 'Gbarpolu', '2023-12-28', 'images/images (4).jfif', '16:30:00', '00:00:00'),
(12, 'International Friendly', '', 'SKD', 'LIberia', 'Nigeria', '2023-12-03', 'images/download (3).jfif', '20:30:00', '00:00:00'),
(13, 'International Friendly', '', 'SKD', 'LIberia', 'South Africa', '2023-12-20', 'images/images (3).jfif', '17:33:00', '00:00:00'),
(14, 'International Friendly', '', 'SKD', 'Nimba', 'Montserrado', '2023-12-21', 'images/AML-Nimba-2-pw2f7rrue7qsqov1jwuzoekt2ps2vm39odwhxzjhxk.jpeg', '19:51:00', '00:00:00'),
(15, 'International Friendly', '', 'SKD', 'LIberia', 'Ghana', '2023-12-27', 'images/images (11).jfif', '18:04:00', '00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `pref_seat`
--

CREATE TABLE `pref_seat` (
  `prefSeat_id` int(11) NOT NULL,
  `event_id` int(11) NOT NULL,
  `area_prefix` varchar(15) NOT NULL,
  `max_seat` varchar(11) NOT NULL,
  `desc` varchar(255) NOT NULL,
  `ticket_price` varchar(11) NOT NULL,
  `currentNum` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `pref_seat`
--

INSERT INTO `pref_seat` (`prefSeat_id`, `event_id`, `area_prefix`, `max_seat`, `desc`, `ticket_price`, `currentNum`) VALUES
(1, 1, 'VP', '100', 'Very Important Person', '500', 3),
(2, 1, 'BL', '7', 'ghjk', '130', 0);

-- --------------------------------------------------------

--
-- Table structure for table `public_users`
--

CREATE TABLE `public_users` (
  `user_id` int(11) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `password` varchar(255) NOT NULL,
  `registration_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `public_users`
--

INSERT INTO `public_users` (`user_id`, `fname`, `lname`, `email`, `phone`, `password`, `registration_date`) VALUES
(1, 'JERRY', 'DORLOPIA', 'goldfinger@gmail.com', '+250790064067', '$2y$10$qrKBstNuhbOl8d2BPyZoHuVi14v/K33GgicWwAQckaZcegOIZ2KIu', '2023-11-24 08:11:37'),
(3, 'Samuel', 'Dolo', 'samuel@gmail.com', '0790064067', '$2y$10$dBw.sjT7dpP9.pNSpu9Jdu2br/ymeBnv1/TxcoSOiSB8poi232xiK', '2023-12-09 12:30:00'),
(4, 'Samuel', 'dolo', 'goldfingerjd@gmail.com', '+250790064067', '$2y$10$IrBXqmkK1DS4TUX4/O92QO..LGbyIki4pY84Qmq7Z0ECnJOMIJRZy', '2023-12-10 19:32:51');

-- --------------------------------------------------------

--
-- Table structure for table `seats`
--

CREATE TABLE `seats` (
  `seat_id` int(11) NOT NULL,
  `row_number` int(11) DEFAULT NULL,
  `col_number` int(11) DEFAULT NULL,
  `class` varchar(20) DEFAULT NULL,
  `price` decimal(5,2) DEFAULT NULL,
  `status` varchar(20) DEFAULT 'available'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sold_tickets`
--

CREATE TABLE `sold_tickets` (
  `trans_id` int(11) NOT NULL,
  `qr_img` varchar(255) NOT NULL,
  `qr_code` varchar(55) NOT NULL,
  `clientLName` varchar(255) NOT NULL,
  `clientFName` varchar(255) NOT NULL,
  `clientContNum` varchar(13) NOT NULL,
  `event_id` int(11) NOT NULL,
  `prefSeat_id` int(11) NOT NULL,
  `trans_date` varchar(10) NOT NULL,
  `trans_time` varchar(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `sold_tickets`
--

INSERT INTO `sold_tickets` (`trans_id`, `qr_img`, `qr_code`, `clientLName`, `clientFName`, `clientContNum`, `event_id`, `prefSeat_id`, `trans_date`, `trans_time`) VALUES
(1, 'temp/VP-1_3aad61fa90eff2c28d3e3c6462b0bd46.png', 'VP-1', 'Magtolis', 'Emilio', '09303546547', 1, 1, '11/27/2019', '09:32:17 AM'),
(2, 'temp/VP-2_28031f43c8becd213b473657a5c6e8ec.png', 'VP-2', 'Test', 'Test', '0930xxxxxxx', 1, 1, '09/03/2020', '10:59:19 PM'),
(3, 'temp/VP-3_33c0bb842560ca3d41175a2943ee5134.png', 'VP-3', 'John', 'Doe', '09091234567', 1, 1, '09/03/2020', '11:12:49 PM');

-- --------------------------------------------------------

--
-- Table structure for table `useraccounts`
--

CREATE TABLE `useraccounts` (
  `user_id` int(11) NOT NULL,
  `reg_id` int(11) NOT NULL,
  `lname` varchar(55) NOT NULL,
  `fname` varchar(55) NOT NULL,
  `username` varchar(55) NOT NULL,
  `password` varchar(55) NOT NULL,
  `access` varchar(55) NOT NULL,
  `status` varchar(55) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

--
-- Dumping data for table `useraccounts`
--

INSERT INTO `useraccounts` (`user_id`, `reg_id`, `lname`, `fname`, `username`, `password`, `access`, `status`) VALUES
(1, 0, 'Magtolis', 'Emiloi', 'emiloi', 'a1Bz20ydqelm8m1wql21232f297a57a5a743894a0e4a801fc3', 'Administrator', 'Active');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `booked_seats`
--
ALTER TABLE `booked_seats`
  ADD PRIMARY KEY (`booking_id`),
  ADD KEY `seat_id` (`seat_id`);

--
-- Indexes for table `bookings`
--
ALTER TABLE `bookings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pref_event`
--
ALTER TABLE `pref_event`
  ADD PRIMARY KEY (`event_id`);

--
-- Indexes for table `pref_seat`
--
ALTER TABLE `pref_seat`
  ADD PRIMARY KEY (`prefSeat_id`);

--
-- Indexes for table `public_users`
--
ALTER TABLE `public_users`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `seats`
--
ALTER TABLE `seats`
  ADD PRIMARY KEY (`seat_id`);

--
-- Indexes for table `sold_tickets`
--
ALTER TABLE `sold_tickets`
  ADD PRIMARY KEY (`trans_id`);

--
-- Indexes for table `useraccounts`
--
ALTER TABLE `useraccounts`
  ADD PRIMARY KEY (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `booked_seats`
--
ALTER TABLE `booked_seats`
  MODIFY `booking_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bookings`
--
ALTER TABLE `bookings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=142;

--
-- AUTO_INCREMENT for table `pref_event`
--
ALTER TABLE `pref_event`
  MODIFY `event_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `pref_seat`
--
ALTER TABLE `pref_seat`
  MODIFY `prefSeat_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `public_users`
--
ALTER TABLE `public_users`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `seats`
--
ALTER TABLE `seats`
  MODIFY `seat_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `sold_tickets`
--
ALTER TABLE `sold_tickets`
  MODIFY `trans_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `useraccounts`
--
ALTER TABLE `useraccounts`
  MODIFY `user_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `booked_seats`
--
ALTER TABLE `booked_seats`
  ADD CONSTRAINT `booked_seats_ibfk_1` FOREIGN KEY (`seat_id`) REFERENCES `seats` (`seat_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
